/**
 * Created by dell on 03/10/2022.
 */
public class hw3 {
    public static void main(String[] args) {
        String s="Mississippi";
        System.out.println(s.replace("i","!"));
        System.out.println(s.replace("a","$"));

    }
}
