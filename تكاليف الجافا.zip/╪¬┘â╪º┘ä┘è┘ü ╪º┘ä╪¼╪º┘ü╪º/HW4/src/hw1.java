import java.awt.*;

/**
 * Created by dell on 03/10/2022.
 */
public class hw1 {
    public static void main(String[] args) {
        Rectangle s=new Rectangle(6,10);
        System.out.println(60 + "=النتيجة المتوقعة");
        System.out.println("erea=" +s.getWidth()*s.getHeight());

    }
}
