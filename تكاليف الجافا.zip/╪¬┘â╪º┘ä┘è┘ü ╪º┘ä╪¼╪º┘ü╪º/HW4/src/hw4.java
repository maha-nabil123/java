/**
 * Created by dell on 03/10/2022.
 */
public class hw4 {
    public static void main(String[] args) {
        String s="maha almazagy";
        StringBuilder r=new StringBuilder(s);
        r.reverse();
        String text=r.toString();
        System.out.println("rajnla abas = النتيجة المتوقعة");
        System.out.println("original string:"+5);
        System.out.println("Reversed string:"+text);

    }
}
