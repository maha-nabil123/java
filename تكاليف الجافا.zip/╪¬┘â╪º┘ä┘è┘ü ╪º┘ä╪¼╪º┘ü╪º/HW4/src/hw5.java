/**
 * Created by dell on 04/10/2022.
 */
public class hw5 {
    public static void main(String[] args) {
        double RandomNumber = Math.random();
        System.out.println(RandomNumber);

    }
}
