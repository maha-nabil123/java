import javax.swing.*;
import java.awt.*;

/**
 * Created by dell on 04/10/2022.
 */
public class hw6 {
    public static void main(String[] args) {
        JFrame frame=new JFrame();
        frame.setSize(400,400);
        JLabel label =new JLabel("Hello , Maha");
        label.setOpaque(true);
        label.setBackground(Color.GREEN);
        frame.add(label);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
