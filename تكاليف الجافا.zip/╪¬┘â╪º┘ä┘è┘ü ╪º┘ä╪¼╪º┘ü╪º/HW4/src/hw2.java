/**
 * Created by dell on 03/10/2022.
 */
public class hw2 {
    public static void main(String[] args) {
        String s="Mississippi";
        System.out.println(s.replace("i","ii"));
        System.out.println(s.length());
        System.out.println(s.replace("ss","s"));
        System.out.println(s.length());
    }
}
