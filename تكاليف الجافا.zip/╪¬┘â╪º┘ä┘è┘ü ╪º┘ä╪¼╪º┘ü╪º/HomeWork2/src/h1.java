/**
 * Created by dell on 10/09/2022.
 */
public class h1 {
    public static void main(String[] args) {
        System.out.println("The output of:\n4.0*(1-(1.0/3)+(1.0/7)+(1.0/9)-(1.0/11)");
        System.out.println("is<<");
        System.out.println(4.0*(1-(1.0/3)+(1.0/7)+(1.0/9)-(1.0/11)));
    }
}
