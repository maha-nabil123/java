/**
 * Created by dell on 10/09/2022.
 */
public class h2 {
    public static void main(String[] args) {
        System.out.println("محيط الدائرة=" );
        System.out.println(2*3.14*(5*5));
        System.out.println("مساحة الدائرة");
        System.out.println(2*(5*5));

    }
}
