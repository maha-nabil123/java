/**
 * Created by dell on 10/09/2022.
 */
public class h4 {
    public static void main(String[] args) {
        int x=5;
        int y=10;
        ////////
        int swap=x;
        x=y;
        y=swap;
        System.out.println("x="+x+" y="+y);
    }
}
