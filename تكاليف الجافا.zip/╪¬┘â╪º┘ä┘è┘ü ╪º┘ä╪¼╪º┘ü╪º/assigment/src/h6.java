import java.util.Scanner;

/**
 * Created by dell on 10/09/2022.
 */
public class h6 {
    public static void main(String[] args) {
        Scanner cin=new Scanner(System.in);
        String h=cin.next();
        System.out.println(h);
    }
}
