/**
 * Created by dell on 10/09/2022.
 */
public class h1 {
    public static void main(String[] args) {
        System.out.println("the sum:");
        System.out.println("1+2+3+4+5+6+7+8+9+10");
    }
}
