/**
 * Created by dell on 10/09/2022.
 */
public class h2 {
    public static void main(String[] args) {
        System.out.println("مرحبا");
    }
}
