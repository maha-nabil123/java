/**
 * Created by dell on 10/09/2022.
 */
public class h4 {
    public static void main(String[] args) {
        System.out.println("    +   ");
        System.out.println(" +     + ");
        System.out.println("+        +");
        System.out.println(" +--------+ ");
        System.out.println(" | .-. | ");
        System.out.println(" | | | | ");
        System.out.println(" +-+-+-+ ");
    }
}
