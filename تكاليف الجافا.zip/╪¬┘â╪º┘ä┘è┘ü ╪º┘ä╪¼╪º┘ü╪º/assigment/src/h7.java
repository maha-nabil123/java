import javax.swing.*;

/**
 * Created by dell on 10/09/2022.
 */
public class h7 {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog( null,"Hi bro");


    }
}
