/**
 * Created by dell on 11/09/2022.
 */
public class h1 {
    public static void main(String[] args) {

    }
}
