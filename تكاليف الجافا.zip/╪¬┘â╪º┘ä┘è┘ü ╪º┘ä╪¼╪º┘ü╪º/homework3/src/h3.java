import java.util.Scanner;

/**
 * Created by dell on 11/09/2022.
 */
public class h3 {
    public static void main(String[] args) {
        Scanner in=new Scanner("Enter 3 number:");
        int n1= in.nextInt();
        int n2= in.nextInt();
        int n3= in.nextInt();
        if (n1==n2 & n1==n3)
            System.out.println("all sam");
        else if (n1!=n2 & n1!=n3)
            System.out.println("all diffrint");
        else
            System.out.println("neither");
    }
}
